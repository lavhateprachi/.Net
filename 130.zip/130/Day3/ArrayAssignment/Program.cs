﻿namespace ArrayAssignment
{

    //YCP has certain number of batches. each batch has certain number of students
    //         accept number of batches. for each batch accept number of students.
    //         create an array to store mark for each student (1 student has only 1 subject mark)
    //        accept the marks.
    //        display the marks.
    internal class Program
    {
        static void Main(string[] args)
        {
            //read no of batches from user
            Console.Write("Enter no of batches: ");
            int m = int.Parse(Console.ReadLine()!);
            
            float[][] studentMarks = new float[m][];

            //for each batch read no of students
            for(int i = 0; i < m; i++)
            {
                Console.Write($"Enter no of students for batch-{i+1} :");
                int n = Convert.ToInt32(Console.ReadLine());
                studentMarks[i] = new float[n];
            }

            //read data(marks) from user
            for (int i = 0; i < studentMarks.Length; i++) 
            {
                for (int j = 0; j < studentMarks[i].Length; j++)
                {
                    Console.Write($"Enter marks for student{j+1} of batch-{i+1} ");
                    studentMarks[i][j] =Convert.ToSingle(Console.ReadLine());
                }
            }

            //display marks data
            for (int i = 0; i < studentMarks.Length; i++)
            {
                for (int j = 0; j < studentMarks[i].Length; j++)
                {
                    Console.Write($"Student{j+1} of batch {i+1} ");
                    Console.WriteLine(studentMarks[i][j]);
                }
            }

        }
    }
}

