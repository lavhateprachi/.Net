﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    internal class Inheritance
    {
        static void Main()
        {
            GeneralManager gm = new GeneralManager();
            Console.WriteLine($"General Manager: {gm.ToString()}");
            Console.WriteLine("Salary= " + gm.CalcNetSalary());

            GeneralManager gm2 = new GeneralManager("TA-DA", "Software Developer", "Krupa", 2, 50000);
            Console.WriteLine($"General Manager: {gm2.ToString()}");
            Console.WriteLine("Salary= " + gm2.CalcNetSalary());

            Manager mgr = new Manager();
            Console.WriteLine($"Manager: {mgr.ToString()}");
            Console.WriteLine("Salary= " + mgr.CalcNetSalary());

            CEO ceo = new CEO();
            Console.WriteLine($"CEO: {ceo.ToString()}");
            Console.WriteLine("Salary= " + ceo.CalcNetSalary());

        }
    }
    public interface IDbFunctions
    {
        void Insert();
        void Update();
        void Delete();
    }

    abstract class Employee: IDbFunctions {
        private static int incEmpNo;
        private string name;
        public string Name
        {
            set
            {
                if (value != null)
                {
                    name = value;
                }
                else
                {
                    Console.WriteLine("Invalid name");
                }
            }
            get
            {
                return name;
            }
        }

        private int empNo;
        internal protected int EmpNo{
            get {  return empNo; }
            private set
            {
                empNo = value;
            }
        }

        private short deptNo;
        internal short DeptNo
        {
            set
            {
                if(value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    Console.WriteLine("Invalid Emp no");
                }
            }
            get { return deptNo; }
        }

        protected decimal basic;
        protected abstract decimal Basic
        {
            get; set;
        }

        public Employee(string name="Anmol", short deptNo = 1, decimal basic = 30000)
        {
            this.Name = name!;
            this.DeptNo = deptNo;
            this.Basic = basic;
            this.EmpNo = ++incEmpNo;
        }
        public abstract decimal CalcNetSalary();

        public void Insert()
        {
            Console.WriteLine("IDBFunctions.Insert() in Employee class");
        }

        public void Update()
        {
            Console.WriteLine("IDBFunctions.Update() in Employee class");
        }

        public void Delete()
        {
            Console.WriteLine("IDBFunctions.Delete() in Employee class");
        }
        public override string ToString()
        {
            return "Employee: EmpNo= " + EmpNo + ", Name= " + Name + ", Dept No= " + DeptNo + ", Basic= " + Basic;
        }
    }

    //NOTE : Overloaded constructors in all classes calling their base class constructor
    //All classes must implement IDbFunctions interface
    //All classes to override the abstract members defined in the base class(Employee).
    //Basic property to have different validation in different classes.
    //CalcNetSalary() to have different calculation in different classes.

    class Manager : Employee, IDbFunctions //by default inheritance mode is public
    {
        private string designation;
        public string Designation
        {
            set
            {
                if( value != null)
                {
                    designation = value;
                }
                else
                {
                    Console.WriteLine("Invalid Designation");
                }
            }
            get
            {
                return designation;
            }
        }

        protected override decimal Basic {
            get
            {
                return basic;
            }
            set
            {
                if(value < 10000)
                {
                    Console.WriteLine("Invalid Basic Sal for Manager");
                }
                else
                {
                    basic = value;
                }
            } 
        }

        public Manager(string designation="Lecturer", string name= "Anmol", short deptNo = 1, decimal basic=30000): base(name, deptNo, basic)
        {
            this.Designation = designation;
        }
        public override decimal CalcNetSalary()
        {
            return Basic + Basic * (Decimal)0.2 + Basic * (Decimal)0.8;
        }

        public new void Insert()
        {
            Console.WriteLine("IDBFunctions.Insert() in Manager class");
        }

        public new void Update()
        {
            Console.WriteLine("IDBFunctions.Update() in Manager class");
        }

        public new void Delete()
        {
            Console.WriteLine("IDBFunctions.Delete() in Manager class");
        }
        public override string ToString()
        {
            return base.ToString() + ", Designation= " + Designation;
        }
    }

    class GeneralManager: Manager, IDbFunctions
    {
     //   private string perks;
        public string Perks { set; get; }

        protected override decimal Basic
        {
            get
            {
                return basic;
            }
            set
            {
                if(value < 30000)
                {
                    Console.WriteLine("Invalid Basic sal for General Manager");
                }
                else
                {
                    basic = value;
                }
            }
        }
        public GeneralManager(string perks = "default", string designation="Lecturer", string name="Anmol", short deptNo=1, decimal basic=40000)
            :base(designation, name, deptNo, basic)
        {
            this.Perks = perks;
        }
        public override decimal CalcNetSalary()
        {
            return Basic + Basic * (Decimal)0.4 + Basic * (Decimal)0.8;
        }
        public new void Insert()
        {
            Console.WriteLine("IDBFunctions.Insert() in GeneralManager class");
        }

        public new void Update()
        {
            Console.WriteLine("IDBFunctions.Update() in GeneralManager class");
        }

        public new void Delete()
        {
            Console.WriteLine("IDBFunctions.Delete() in GeneralManager class");
        }

        public override string ToString()
        {
            return base.ToString() + ", Perks= " +Perks;
        }
    }
    class CEO : GeneralManager, IDbFunctions
    {
        public CEO(string perks = "default", string designation = "Lecturer", string name = "Anmol", short deptNo = 1, decimal basic = 40000)
            : base(perks, designation, name, deptNo, basic)
        {
            Console.WriteLine("In CEO ctor");
        }
        public sealed override decimal CalcNetSalary()
        {
            return Basic + Basic * (Decimal)0.4 + Basic * (Decimal)0.8 + 4000;
        }
        public override string ToString()
        {
            return base.ToString();
        }
    }

}
