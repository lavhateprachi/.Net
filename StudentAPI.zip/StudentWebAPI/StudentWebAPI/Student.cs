﻿using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client;

namespace StudentWebAPI
{
    public class Student
    {

        public int Id { get; set; }
        public string? FName { get; set; }
        public string? LName { get; set; }
        public string? Email { get; set; }

        public decimal Marks { get; set; }


        public static List<Student> getAllStudents()
        {
            List<Student> students = new List<Student>();
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "select * from Std";

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        Student std = new Student();

                        std.Id = Convert.ToInt32(dr[0]);
                        std.FName = dr[1].ToString();
                        std.LName = dr[2].ToString();
                        std.Email = dr[3].ToString();
                        std.Marks = (decimal)dr[4];

                        students.Add(std);
                    }
                    return students;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        public static Student getSingleStudent(int id)
        {

            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "select * from Std where PRN=@PRN";

                    cmd.Parameters.AddWithValue("@PRN", id);

                    SqlDataReader dr = cmd.ExecuteReader();
                    Student std = new Student();
                    if (dr.Read())
                    {

                        std.Id = Convert.ToInt32(dr[0]);
                        std.FName = dr[1].ToString();
                        std.LName = dr[2].ToString();
                        std.Email = dr[3].ToString();
                        std.Marks = (decimal)dr[4];


                    }
                    return std;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        public static void Insert(Student student)
        {
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "InsertIntoDB";

                    cmd.Parameters.AddWithValue("@first", student.FName);
                    cmd.Parameters.AddWithValue("@last", student.LName);
                    cmd.Parameters.AddWithValue("@email", student.Email);
                    cmd.Parameters.AddWithValue("@marks", student.Marks);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        public static void Update(int id, Student std)
        {
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "update Std set first=@first,last=@last,email=@email,marks=@marks where PRN=@PRN";

                    cmd.Parameters.AddWithValue("@PRN", id);
                    cmd.Parameters.AddWithValue("@first", std.FName);
                    cmd.Parameters.AddWithValue("@last", std.LName);
                    cmd.Parameters.AddWithValue("@email", std.Email);
                    cmd.Parameters.AddWithValue("@marks", std.Marks);

                    cmd.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    throw e;
                }

            }
        }
        public static void delete(int id)
        {
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "delete from Std where PRN=@PRN";

                    cmd.Parameters.AddWithValue("@PRN", id);
                    
                    cmd.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    throw e;
                }

            }
        }
    }
}
