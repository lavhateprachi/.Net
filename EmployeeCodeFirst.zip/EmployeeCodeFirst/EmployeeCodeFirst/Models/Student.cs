﻿using Microsoft.Identity.Client;
using System.ComponentModel.DataAnnotations;

namespace EmployeeCodeFirst.Models
{
    public class Student
    {
        [Key]
        public int PRN { get; set; }
        
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public int Marks {  get; set; }

    }
}
