﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BookWebApi
{
    public class Book
    {
        public int BookId { get; set; }
        public string? BookName { get; set; }
        public string? BookAuthor { get; set; }

        public decimal BookPrice { get; set; }


        public static List<Book> populateBooks()
        {
            List<Book> Books = new List<Book>();
            Books.Add(new Book { BookId = 1, BookName = "Bakula", BookAuthor = "Sudha Murthy", BookPrice = 250 });
            Books.Add(new Book { BookId = 2, BookName = "Shyamachi Aai", BookAuthor = "Sane Guruji", BookPrice = 350 });
            Books.Add(new Book { BookId = 3, BookName = "Agnipankh", BookAuthor = "Dr.A.P.J.Abdul Kalam", BookPrice = 287 });
            Books.Add(new Book { BookId = 4, BookName = "Mahashweta", BookAuthor = "Sudha Murthy", BookPrice = 275 });
            Books.Add(new Book { BookId = 5, BookName = "Shukesini", BookAuthor = "Sudha Murthy", BookPrice = 320 });

            return Books;
        }

        public static List<Book> GetAllBooks()
        {
            List<Book> books = new List<Book>();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;

                //cmd.CommandType = System.Data.CommandType.Text;
                //cmd.CommandText = "select * from Books";

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetAllBooks";

                Book b;
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    b = new Book();
                    b.BookId = Convert.ToInt32(dr[0]);
                    b.BookName = dr[1].ToString();
                    b.BookAuthor = dr[2].ToString();
                    b.BookPrice = Convert.ToDecimal(dr[3]);

                    books.Add(b);
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            return books;
        }

        public static void Insert(Book book)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                //cmd.CommandType = System.Data.CommandType.Text;
                //cmd.CommandText = "insert into Books values (@BookId,@BookName,@BookAuthor,@BookPrice)";

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "InsertBook";



                cmd.Parameters.AddWithValue("@BookId", book.BookId);
                cmd.Parameters.AddWithValue("@BookName", book.BookName);
                cmd.Parameters.AddWithValue("@BookAuthor", book.BookAuthor);
                cmd.Parameters.AddWithValue("@BookPrice", book.BookPrice);

                cmd.ExecuteNonQuery();

                Console.WriteLine("Successfully Inserted....");


            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed To Insert....");
            }
        }

        public static Book GetSingleBook(int BookId)
        {
            Book obj = new Book();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                //cmdInsert.CommandType = System.Data.CommandType.Text;
                //cmdInsert.CommandText = "select * from Books where BookId=@BookId";

                cmdInsert.CommandType = CommandType.StoredProcedure;
                cmdInsert.CommandText = "GetSingleBook";

                cmdInsert.Parameters.AddWithValue("@BookId", BookId);
                SqlDataReader dr = cmdInsert.ExecuteReader();
                if (dr.Read())
                {
                    obj.BookId = dr.GetInt32("BookId");
                    obj.BookName = dr.GetString("BookName");
                    obj.BookAuthor = dr.GetString("BookAuthor");
                    obj.BookPrice = dr.GetDecimal("BookPrice");
                }
                else
                {
                    obj = null;
                    //record not present
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            return obj;
        }

        public static void Update(Book book)
        {
            SqlConnection sqlConnection = new SqlConnection();

            sqlConnection.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                sqlConnection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlConnection;

                //cmd.CommandType = System.Data.CommandType.Text;
                //cmd.CommandText = "update Books set BookName=@BookName,BookAuthor=@BookAuthor,BookPrice=@BookPrice where BookId=@BookId";


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UpdateBook";

                cmd.Parameters.AddWithValue("@BookId", book.BookId);
                cmd.Parameters.AddWithValue("@BookName", book.BookName);
                cmd.Parameters.AddWithValue("@BookAuthor", book.BookAuthor);
                cmd.Parameters.AddWithValue("@BookPrice", book.BookPrice);

                cmd.ExecuteNonQuery();

                Console.WriteLine("Successfully Updated....");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed To Update....");
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public static void Delete(int id)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                //cmd.CommandType = System.Data.CommandType.Text;
                //cmd.CommandText = "delete from Books where BookId=@BookId";

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DeleteBook";
                cmd.Parameters.AddWithValue("@BookId", id);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Deleted Successfully!!!!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed To Delete...");
            }
            finally
            {
                cn.Close();
            }

        }
    }
}
