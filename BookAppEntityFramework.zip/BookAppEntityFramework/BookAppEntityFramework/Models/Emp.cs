﻿using System;
using System.Collections.Generic;

namespace BookAppEntityFramework.Models;

public partial class Emp
{
    public int EmpId { get; set; }

    public string? Name { get; set; }

    public string? City { get; set; }

    public string? Address { get; set; }
}
