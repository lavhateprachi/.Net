﻿using Microsoft.Data.SqlClient;
using System.Data;


namespace Day9
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //Connect();
            //Insert1();
            //Employee employee = new Employee { EmpNo=4,Name="Isha",Basic=150000,DeptNo=30};
            //Insert4(employee);

            //SelectSingleValue();

            //List<Employee> employees = new List<Employee>();
            //employees = GetAllEmployees();
            //foreach (Employee emp in employees)
            //{
            //    Console.WriteLine(emp);
            //}

            Employee employee = new Employee();
            Console.WriteLine("Enter Employee No: ");
            employee = GetSingleEmployee(Convert.ToInt32(Console.ReadLine()));
            Console.WriteLine(employee);

        }

        private static void Connect()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            try
            {
                cn.Open();
                Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();

            }

        }

        private static void Insert1()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();

                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "insert into Employees values(1,'Neha',20000,10)";
                cmdInsert.ExecuteNonQuery();

                Console.WriteLine("Successfully Inserted...");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private static void Insert2(Employee obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = $"insert into Employees values({obj.EmpNo},'{obj.Name}',{obj.Basic},{obj.DeptNo})";

                //Console.WriteLine(cmd.CommandText);
                //Console.ReadLine();
                cmd.ExecuteNonQuery();
                Console.WriteLine("Inserted Employee Successfully..");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private static void Insert3(Employee obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.CommandText =
                "insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";

                cmdInsert.Parameters.AddWithValue("@EmpNo", obj.EmpNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Basic", obj.Basic);
                cmdInsert.Parameters.AddWithValue("@DeptNo", obj.DeptNo);

                cmdInsert.ExecuteNonQuery();
                Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private static void Insert4(Employee obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.StoredProcedure;
                cmdInsert.CommandText = "InsertEmployeeProcedure";

                cmdInsert.Parameters.AddWithValue("@EmpNo", obj.EmpNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Basic", obj.Basic);
                cmdInsert.Parameters.AddWithValue("@DeptNo", obj.DeptNo);

                cmdInsert.ExecuteNonQuery();
                Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private static void SelectSingleValue()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                //cmd.CommandText = "select Name from Employees where EmpNo=1";

                cmd.CommandText = "select count(*) from Employees";

                object value = cmd.ExecuteScalar();
                Console.WriteLine(value);
                Console.WriteLine("Success");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private static List<Employee> GetAllEmployees()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            List<Employee> list = new List<Employee>();
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "FetchAllEmployee";

                SqlDataReader dr = cmd.ExecuteReader();

                Employee emp ;
                while (dr.Read())
                {
                    emp = new Employee();
                    //emp.EmpNo = dr.GetInt32(0);
                    //emp.Name = dr.GetString(1);
                    //emp.Basic =dr.GetDecimal(2);
                    //emp.DeptNo =dr.GetInt32(3);
                    emp.EmpNo = Convert.ToInt32( dr[0]);
                    emp.Name = dr[1].ToString(); ;
                    emp.Basic = Convert.ToDecimal(dr[2]);
                    emp.DeptNo = Convert.ToInt32(dr[3]);

                    list.Add(emp);

                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
            return list;
        }

        private static Employee GetSingleEmployee(int empNo)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            Employee emp = new Employee();
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from Employees where EmpNo = empNo";

                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.Read())
                {
                    emp.EmpNo = Convert.ToInt32(dr[0]);
                    emp.Name = dr[1].ToString(); ;
                    emp.Basic = Convert.ToDecimal(dr[2]);
                    emp.DeptNo = Convert.ToInt32(dr[3]);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally {
                cn.Close();
            }
            return emp;

        }
    }



    public class Employee
    {
        public int EmpNo { get; set; }
        public string? Name { get; set; }
        public decimal Basic { get; set; }
        public int DeptNo { get; set; }


        public override string ToString()
        {
            return "EmpNo: " + EmpNo + "  " + "EmpName: " + Name + "  " + "Basic: " + Basic + "  " + "DeptNo: " + DeptNo;
        }
    }
}