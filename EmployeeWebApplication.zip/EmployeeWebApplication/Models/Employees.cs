﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace EmployeeWebApplication.Models
{
    public class Employees
    {
        public int EmpNo { get; set; }
        public string? Name { get; set; }
        public decimal Basic { get; set; }
        public int DeptNo { get; set; }


        public static List<Employees> pupulateData()
        {
            List<Employees> employees = new List<Employees>();
            employees.Add(new Employees { EmpNo = 1, Name = "Aditya", Basic = 200000, DeptNo = 10 });
            employees.Add(new Employees { EmpNo = 2, Name = "Neha", Basic = 500000, DeptNo = 10 });
            employees.Add(new Employees { EmpNo = 3, Name = "Isha", Basic = 610000, DeptNo = 20 });
            employees.Add(new Employees { EmpNo = 4, Name = "Samiksha", Basic = 205000, DeptNo = 30 });

            return employees;

        }

        public static List<Employees> GetAllEmployees()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            List<Employees> list = new List<Employees>();
            try 
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "FetchAllEmployee";

                SqlDataReader dr = cmd.ExecuteReader();

                Employees emp;
                while (dr.Read())
                {
                    emp = new Employees();
                    emp.EmpNo = Convert.ToInt32(dr[0]);
                    emp.Name = dr[1].ToString(); ;
                    emp.Basic = Convert.ToDecimal(dr[2]);
                    emp.DeptNo = Convert.ToInt32(dr[3]);

                    list.Add(emp);

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
            return list;
        }

        public static Employees GetSingleEmployee(int EmpNo)
        {
            Employees obj = new Employees();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "select * from Employees where empno=@EmpNo";
                cmdInsert.Parameters.AddWithValue("@EmpNo", EmpNo);
                SqlDataReader dr = cmdInsert.ExecuteReader();
                if (dr.Read())
                {
                    obj.EmpNo = dr.GetInt32("EmpNo");
                    obj.Name = dr.GetString("Name");
                    obj.Basic = dr.GetDecimal("Basic");
                    obj.DeptNo = dr.GetInt32("DeptNo");
                }
                else
                {
                    obj = null;
                    //record not present
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            return obj;
        }



        public static void Insert(Employees obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.CommandText =
                "insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";

                cmdInsert.Parameters.AddWithValue("@EmpNo", obj.EmpNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Basic", obj.Basic);
                cmdInsert.Parameters.AddWithValue("@DeptNo", obj.DeptNo);

                cmdInsert.ExecuteNonQuery();
                //Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                throw;
            }
            finally
            {
                cn.Close();
            }
        }

        public static void Update(Employees obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();

                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "update Employees set Name=@Name,Basic=@Basic,DeptNo=@DeptNo where EmpNo=@EmpNo";


                cmdInsert.Parameters.AddWithValue("@EmpNo", obj.EmpNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Basic", obj.Basic);
                cmdInsert.Parameters.AddWithValue("@DeptNo", obj.DeptNo);

                cmdInsert.ExecuteNonQuery();

                Console.WriteLine("Successfully Updated...");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }

        }
        public static void Delete(int id)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();

                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "Delete from Employees where EmpNo=@EmpNo";


                cmdInsert.Parameters.AddWithValue("@EmpNo", id);


                cmdInsert.ExecuteNonQuery();

                Console.WriteLine("Successfully Deleted...");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

    }
}
