﻿using EmployeeWebApplication.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeWebApplication.Controllers
{
    public class ActsController : Controller
    {
        // GET: ActsController
        public ActionResult Index()
        {

            List<Employees> list = Employees.GetAllEmployees();
            return View(list);
        }

        // GET: ActsController/Details/5
        public ActionResult Details(int id)
        {
            Employees obj = Employees.GetSingleEmployee(id);
            return View(obj);
        }

        // GET: ActsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ActsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employees obj)
        {
            try
            {
                Employees.Insert(obj);
                //return RedirectToAction(nameof(Index));

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: ActsController/Edit/5
        public ActionResult Edit(int id)
        {
            Employees obj = Employees.GetSingleEmployee(id);
            return View(obj);
        }

        // POST: ActsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employees obj)
        {
            try
            {
                Employees.Update(obj);  
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ActsController/Delete/5
        public ActionResult Delete(int id)
        {
            Employees obj = Employees.GetSingleEmployee(id);
            return View(obj);
        }

        // POST: ActsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Employees.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
