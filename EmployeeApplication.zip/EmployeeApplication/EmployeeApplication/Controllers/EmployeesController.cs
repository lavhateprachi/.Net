﻿using EmployeeApplication.Models;
using EmployeeApplication.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeApplication.Controllers
{
    public class EmployeesController : Controller
    {
        IEmployeeService employeeService;
        public EmployeesController(IEmployeeService service) { 
            this.employeeService = service;
        
        }

        // GET: EmployeesController
        public ActionResult Index()
        {

            return View(employeeService.GetAllEmployee());
        }

        // GET: EmployeesController/Details/5
        public ActionResult Details(int id)
        {
            Employee e = employeeService.GetEmployeeById(id);
            return View(e);
        }

        // GET: EmployeesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee obj)
        {
            try
            {
                employeeService.AddEmployee(obj);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeesController/Edit/5
        public ActionResult Edit(int id)
        {
            Employee e = employeeService.GetEmployeeById(id);
            return View(e);
        }

        // POST: EmployeesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee emp)
        {
            try
            {
                employeeService.UpdateEmployee(id, emp);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeesController/Delete/5
        public ActionResult Delete(int id)
        {
            Employee e = employeeService.GetEmployeeById(id);
            return View(e);
        }

        // POST: EmployeesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                employeeService.DeleteEmployee(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
