﻿using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;
namespace EmployeeApplication.Models
{
    public class Employee
    {

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="Enter Employee Name")]
        [StringLength(30,MinimumLength =6 ,ErrorMessage ="First name should be minimum 6 characters and a max of 30 characters!!!")]
        [DataType(DataType.Text)]
        [Display(Name="Employee Name")]
        public string? Name { get; set; }

        [Required(ErrorMessage ="Enter City Name")]
        [StringLength(30,ErrorMessage ="City name should contain maximum 30 characters....")]
        [DataType(DataType.Text)]
        [Display(Name = "City Name")]
        public string? City { get; set; }


        [Required(ErrorMessage ="Enter Employee Address")]
        [StringLength(50,ErrorMessage ="Address should contain maximum 50 characters...")]
        [DataType(DataType.Text)]
        [Display(Name="Employee Address")]
        public string? Address { get; set; }

                    public static List<Employee> GetAllEmployee()
        {
            using(SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();    
                    cmd.CommandType=System.Data.CommandType.Text;
                    cmd.CommandText = "select * from Emp";

                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Employee> list = new List<Employee>();
                    while (dr.Read())
                    {
                        Employee emp = new Employee();
                        emp.Id = Convert.ToInt32(dr["EmpId"]);
                        emp.Name = dr["Name"].ToString();
                        emp.City = dr["City"].ToString();
                        emp.Address = dr["Address"].ToString();

                        list.Add(emp);
                    }

                    return list;
                }catch(Exception ex)
                {
                    throw ex;
                }
            }
        }

        public static Employee getSingleEmployee(int EmpId)
        {
            Employee emp = new Employee();
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "select * from Emp where EmpId=@EmpId";
                    cmd.Parameters.AddWithValue("@EmpId", EmpId);
                    SqlDataReader dr = cmd.ExecuteReader();
                    
                    if (dr.Read())
                    {
                        emp.Id = Convert.ToInt32(dr["EmpId"]);
                        emp.Name = dr["Name"].ToString();
                        emp.City = dr["City"].ToString();
                        emp.Address = dr["Address"].ToString() ;
                    }
                    return emp;

                }
                catch(Exception ex) {
                    throw ex;
                }
            }
        }
        public static void insert(Employee emp)
        {
            using(SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType= System.Data.CommandType.Text;
                    cmd.CommandText = "insert into Emp values(@EmpId,@Name,@City,@Address)";

                    cmd.Parameters.AddWithValue("@EmpId",emp.Id);
                    cmd.Parameters.AddWithValue("@Name",emp.Name);
                    cmd.Parameters.AddWithValue("@City", emp.City);
                    cmd.Parameters.AddWithValue("@Address", emp.Address);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public static void updateEmployee(int id,Employee emp)
        {
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "update Emp set Name=@Name,City=@City,Address=@Address where EmpId=@EmpId";

                    cmd.Parameters.AddWithValue("@EmpId", id);
                    cmd.Parameters.AddWithValue("@Name", emp.Name);
                    cmd.Parameters.AddWithValue("@City", emp.City);
                    cmd.Parameters.AddWithValue("address", emp.Address);

                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        public static void deleteEmployee(int id)
        {
            using(SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";


                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType=System.Data.CommandType.Text;
                    cmd.CommandText = "delete from Emp where EmpId=@EmpId";
                    cmd.Parameters.AddWithValue("@EmpId", id);

                    cmd.ExecuteNonQuery();

                }
                catch(Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
