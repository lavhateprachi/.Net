﻿using EmployeeApplication.Models;

namespace EmployeeApplication.Service
{
    public class EmployeeService:IEmployeeService

    {
        public EmployeeService() { }

        public void AddEmployee(Employee employee)
        {
             Employee.insert(employee);
        }

        public void DeleteEmployee(int id)
        {
           Employee.deleteEmployee(id);
        }

        public List<Employee> GetAllEmployee()
        {
            return Employee.GetAllEmployee();
        }

        public Employee GetEmployeeById(int id)
        {
            return Employee.getSingleEmployee(id);
        }

        public void UpdateEmployee(int id, Employee employee)
        {
            Employee.updateEmployee(id, employee);
        }
    }
}
