﻿using EmployeeApplication.Models;
using Microsoft.Identity.Client;

namespace EmployeeApplication.Service
{
    public interface IEmployeeService
    {
        public  List<Employee> GetAllEmployee();

        public Employee GetEmployeeById(int id);

        public void AddEmployee(Employee employee);

        public void UpdateEmployee(int id,Employee employee);  

        public void DeleteEmployee(int id);
    }
}
